﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace AuthSystem.Migrations.MvcMovie
{
    public partial class Myapp : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
